import pandas as pd

# Create summary.xlsx
summary_data = {'Metric': ['Valid Records', 'Invalid Records', 'Total Records'],
                'Count': [12, 3, 15]}
df_summary = pd.DataFrame(summary_data)
df_summary.to_excel('data/summary.xlsx', index=False)

# Create invalid_records.xlsx
invalid_data = {'ID': range(1, 4),
                'Name': ['Record A', 'Record B', 'Record C'],
                'Reason': ['Missing Field', 'Invalid Format', 'Data Error']}
df_invalid = pd.DataFrame(invalid_data)
df_invalid.to_excel('data/invalid_records.xlsx', index=False)

# Create valid_records.xlsx
valid_data = {'ID': range(1, 13),
              'Name': [f'Record {i}' for i in range(4, 16)],
              'Value': [10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120]}
df_valid = pd.DataFrame(valid_data)
df_valid.to_excel('data/valid_records.xlsx', index=False)

print("Sample Excel files created in the 'data' folder.")