import pandas as pd
import math
import os

def get_historical_runs(metadata_file='data/historical_runs.csv'):
    """Reads the historical runs metadata from a CSV file."""
    try:
        df = pd.read_csv(metadata_file)
        df.insert(0, 'sr_no', range(1, 1 + len(df)))
        return df.to_dict('records')
    except FileNotFoundError:
        print(f"Error: Metadata file not found at {metadata_file}")
        return []
    except Exception as e:
        print(f"Error reading historical runs metadata: {e}")
        return []

def get_column_mapping(file_path, sheet_name="Column Mapping"):
    """
    Reads the column mapping from a specified sheet in an Excel file.

    Args:
        file_path (str): The path to the Excel file.
        sheet_name (str): The name of the sheet containing the mapping.

    Returns:
        dict: A dictionary mapping technical names to user-friendly names.
              Returns an empty dictionary if the file, sheet, or required columns are not found.
    """
    if not os.path.exists(file_path):
        # File not found is handled by read_data_file, but good to check early
        return {}

    try:
        # Read the specified mapping sheet
        mapping_df = pd.read_excel(file_path, sheet_name=sheet_name)

        # Ensure the required columns exist
        if 'Technical Name' in mapping_df.columns and 'User-Friendly Name' in mapping_df.columns:
            # Create a dictionary from the mapping
            # Use .dropna() to avoid mapping NaN values
            mapping_dict = mapping_df.dropna(subset=['Technical Name', 'User-Friendly Name']).set_index('Technical Name')['User-Friendly Name'].to_dict()
            return mapping_dict
        else:
            print(f"Warning: Mapping sheet '{sheet_name}' in '{file_path}' does not contain 'Technical Name' and 'User-Friendly Name' columns.")
            return {}
    except FileNotFoundError:
         # This should be caught by read_data_file, but included for completeness
        print(f"Warning: Mapping file/sheet not found: {file_path} (sheet: {sheet_name}).")
        return {}
    except Exception as e:
        print(f"Error reading column mapping from {file_path} (sheet: {sheet_name}): {e}")
        return {}


def read_data_file(file_path):
    """Reads data from Excel, CSV, or text files based on extension."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")

    file_extension = os.path.splitext(file_path)[1].lower()

    try:
        if file_extension == '.xlsx':
            # For Excel, read the first sheet by default
            df = pd.read_excel(file_path, sheet_name=0)
        elif file_extension in ['.csv', '.txt']:
            df = pd.read_csv(file_path)
        else:
            raise ValueError(f"Unsupported file format: {file_extension} for {file_path}")
        return df
    except Exception as e:
        print(f"Error reading data from {file_path}: {e}")
        raise

def get_summary_data(file_path):
    """Reads summary data from the specified data file."""
    try:
        df = read_data_file(file_path)
        if 'Metric' in df.columns and 'Count' in df.columns:
            summary = df.set_index('Metric')['Count'].to_dict()
            total_records = summary.get('Valid Records', 0) + summary.get('Invalid Records', 0)
            summary['Total Records'] = total_records
            return summary
        else:
            print(f"Warning: Summary file {file_path} does not contain 'Metric' and 'Count' columns.")
            return {'Valid Records': 0, 'Invalid Records': 0, 'Total Records': 0}
    except FileNotFoundError:
        print(f"Warning: Summary file not found at {file_path}. Returning zeros.")
        return {'Valid Records': 0, 'Invalid Records': 0, 'Total Records': 0}
    except Exception as e:
        print(f"Error processing summary data from {file_path}: {e}")
        return {'Valid Records': 0, 'Invalid Records': 0, 'Total Records': 0}


def get_all_technical_column_names(file_path): # Renamed function
    """Reads the header row of a data file to get all TECHNICAL column names."""
    try:
        df = read_data_file(file_path).head(0) # Read only the header
        return df.columns.tolist()
    except FileNotFoundError:
        print(f"Warning: File not found at {file_path}. Cannot get technical column names.")
        return []
    except Exception as e:
        print(f"Error getting technical column names from {file_path}: {e}")
        return []


def get_records(file_path, columns_to_fetch=None): # columns_to_fetch are TECHNICAL names
    """
    Reads records from the specified data file and selects specified TECHNICAL columns.

    Args:
        file_path (str): The path to the records data file (.xlsx, .csv, .txt).
        columns_to_fetch (list, optional): A list of TECHNICAL column names to select.
                                          If None, all technical columns are returned.

    Returns:
        list: A list of dictionaries, where each dictionary represents a row
              with TECHNICAL column names as keys. Returns an empty list if the
              file is not found or an error occurs.
    """
    try:
        df = read_data_file(file_path)
        if columns_to_fetch and isinstance(columns_to_fetch, list):
            existing_columns = [col for col in columns_to_fetch if col in df.columns]
            df = df[existing_columns]
        return df.to_dict('records') if not df.empty else []
    except FileNotFoundError:
        print(f"Warning: Records file not found at {file_path}. Returning empty list.")
        return []
    except Exception as e:
        print(f"Error reading records from {file_path}: {e}")
        return []