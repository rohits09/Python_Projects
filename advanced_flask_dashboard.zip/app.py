
from flask import Flask, render_template, send_from_directory
import pandas as pd
import os

app = Flask(__name__)

# File paths
SUCCESS_FILE = 'data/success_records.xlsx'
FAILURE_FILE = 'data/failure_records.xlsx'

@app.route('/')
def home():
    success_df = pd.read_excel(SUCCESS_FILE)
    failure_df = pd.read_excel(FAILURE_FILE)

    total = len(success_df) + len(failure_df)
    return render_template('index.html',
                           valid=len(success_df),
                           invalid=len(failure_df),
                           total=total)

@app.route('/valid')
def valid_records():
    df = pd.read_excel(SUCCESS_FILE)
    return render_template('records.html', records=df.to_dict(orient='records'), title='Valid Records')

@app.route('/invalid')
def invalid_records():
    df = pd.read_excel(FAILURE_FILE)
    return render_template('records.html', records=df.to_dict(orient='records'), title='Invalid Records')

if __name__ == '__main__':
    app.run(debug=True)
