import pandas as pd

def get_summary_data(file_path='data/summary.xlsx'):
    """Reads summary data from the Excel file."""
    try:
        df = pd.read_excel(file_path)
        summary = df.set_index('Metric')['Count'].to_dict()
        total_records = summary.get('Valid Records', 0) + summary.get('Invalid Records', 0)
        summary['Total Records'] = total_records
        return summary
    except FileNotFoundError:
        return {'Valid Records': 0, 'Invalid Records': 0, 'Total Records': 0}
    except Exception as e:
        print(f"Error reading summary data: {e}")
        return {'Valid Records': 0, 'Invalid Records': 0, 'Total Records': 0}

def get_all_column_names(file_path):
    """Reads the header row of an Excel file to get all column names."""
    try:
        df = pd.read_excel(file_path, nrows=0) # Read only the header row
        return df.columns.tolist()
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return []
    except Exception as e:
        print(f"Error getting column names from {file_path}: {e}")
        return []

def get_invalid_records(file_path='data/invalid_records.xlsx', columns_to_fetch=None):
    """
    Reads invalid records from the Excel file and selects specified columns.

    Args:
        file_path (str): The path to the invalid records Excel file.
        columns_to_fetch (list, optional): A list of column names to select.
                                          If None, all columns are returned.

    Returns:
        list: A list of dictionaries, where each dictionary represents a row
              with only the specified columns. Returns an empty list if the
              file is not found or an error occurs.
    """
    try:
        df = pd.read_excel(file_path)
        if columns_to_fetch and isinstance(columns_to_fetch, list):
            # Select only the specified columns that actually exist
            existing_columns = [col for col in columns_to_fetch if col in df.columns]
            df = df[existing_columns]
        # Ensure data is returned as list of dictionaries, even if no columns were selected
        return df.to_dict('records') if not df.empty else []
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return []
    except Exception as e:
        print(f"Error reading invalid records: {e}")
        return []

def get_valid_records(file_path='data/valid_records.xlsx', columns_to_fetch=None):
    """
    Reads valid records from the Excel file and selects specified columns.

    Args:
        file_path (str): The path to the valid records Excel file.
        columns_to_fetch (list, optional): A list of column names to select.
                                          If None, all columns are returned.

    Returns:
        list: A list of dictionaries, where each dictionary represents a row
              with only the specified columns. Returns an empty list if the
              file is not found or an error occurs.
    """
    try:
        df = pd.read_excel(file_path)
        if columns_to_fetch and isinstance(columns_to_fetch, list):
             # Select only the specified columns that actually exist
            existing_columns = [col for col in columns_to_fetch if col in df.columns]
            df = df[existing_columns]
        # Ensure data is returned as list of dictionaries, even if no columns were selected
        return df.to_dict('records') if not df.empty else []
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return []
    except Exception as e:
        print(f"Error reading valid records: {e}")
        return []

# Example usage (for testing) - Updated for column names
if __name__ == '__main__':
    # Create dummy data files if they don't exist for testing
    # (Ensure these files have more than 5-7 columns for pagination testing)
    try:
        pd.read_excel('data/summary.xlsx')
    except FileNotFoundError:
        print("Creating dummy data/summary.xlsx")
        summary_data = {'Metric': ['Valid Records', 'Invalid Records'],
                        'Count': [12, 3]}
        df_summary = pd.DataFrame(summary_data)
        df_summary.to_excel('data/summary.xlsx', index=False)

    try:
        pd.read_excel('data/invalid_records.xlsx')
    except FileNotFoundError:
        print("Creating dummy data/invalid_records.xlsx (with more columns)")
        invalid_data = {
            'ID': range(1, 16), # More rows for potential row pagination later
            'Name': [f'Inv Record {i}' for i in range(1, 16)],
            'Reason': ['Missing Field'] * 5 + ['Invalid Format'] * 5 + ['Data Error'] * 5,
            'Timestamp': pd.to_datetime([f'2023-01-{d}' for d in range(1, 16)]),
            'SourceFile': [f'file{i % 3 + 1}.csv' for i in range(15)],
            'ErrorCode': [101, 102] * 7 + [103],
            'Details': [f'Detail for {i}' for i in range(1, 16)],
            'Severity': ['High'] * 3 + ['Medium'] * 7 + ['Low'] * 5
        }
        df_invalid = pd.DataFrame(invalid_data)
        df_invalid.to_excel('data/invalid_records.xlsx', index=False)

    try:
         pd.read_excel('data/valid_records.xlsx')
    except FileNotFoundError:
        print("Creating dummy data/valid_records.xlsx (with more columns)")
        valid_data = {
            'ID': range(1, 21), # More rows for potential row pagination later
            'Name': [f'Valid Record {i}' for i in range(1, 21)],
            'Value': [i * 10 for i in range(1, 21)],
            'Category': [chr(65 + i % 4) for i in range(20)], # A, B, C, D categories
            'ProcessedDate': pd.to_datetime([f'2023-01-{d}' for d in range(1, 21)]),
            'Status': ['Processed', 'Pending'] * 10,
            'Amount': [i * 100 + 50 for i in range(1, 21)],
            'Currency': ['USD', 'EUR'] * 10,
            'Location': [f'Loc {i % 5 + 1}' for i in range(20)]
        }
        df_valid = pd.DataFrame(valid_data)
        df_valid.to_excel('data/valid_records.xlsx', index=False)


    print("--- Testing Column Names ---")
    invalid_cols = get_all_column_names('data/invalid_records.xlsx')
    print(f"Invalid Columns: {invalid_cols}")
    valid_cols = get_all_column_names('data/valid_records.xlsx')
    print(f"Valid Columns: {valid_cols}")

    print("\n--- Testing Invalid Records (Columns 2 to 4, 0-indexed) ---")
    # Note: columns_to_fetch should be the actual column names
    # We'll handle indexing/slicing in app.py
    # Here, demonstrating fetching specific names
    invalid_subset = get_invalid_records(columns_to_fetch=['Reason', 'Timestamp', 'SourceFile'])
    print(invalid_subset)