from flask import Flask, render_template, send_file, request
import data_operations
import math # Import math for ceil

app = Flask(__name__)

# Define how many columns to show per page
COLS_PER_PAGE = 7 # You can adjust this number

@app.route('/')
def index():
    summary_data = data_operations.get_summary_data()
    return render_template('index.html', summary=summary_data)

@app.route('/invalid')
def invalid_records():
    all_column_names = data_operations.get_all_column_names('data/invalid_records.xlsx')
    total_columns = len(all_column_names)
    total_column_pages = math.ceil(total_columns / COLS_PER_PAGE)

    # Get the current column page from the request URL (default to 1)
    try:
        current_col_page = int(request.args.get('col_page', 1))
    except ValueError:
        current_col_page = 1 # Default to 1 if the parameter is invalid

    # Ensure current_col_page is within valid range
    if current_col_page < 1:
        current_col_page = 1
    elif current_col_page > total_column_pages and total_column_pages > 0:
        current_col_page = total_column_pages
    elif total_column_pages == 0: # Handle case with no columns
        current_col_page = 1


    # Calculate the start and end index for column slicing
    start_col_index = (current_col_page - 1) * COLS_PER_PAGE
    end_col_index = start_col_index + COLS_PER_PAGE

    # Get the subset of column names for the current page
    columns_to_show = all_column_names[start_col_index:end_col_index]

    # Fetch the records with only the selected columns
    invalid_data = data_operations.get_invalid_records(columns_to_fetch=columns_to_show)

    return render_template('invalid_records.html',
                           invalid_records=invalid_data,
                           column_names=columns_to_show, # Pass column names for headers
                           current_col_page=current_col_page,
                           total_column_pages=total_column_pages)

@app.route('/valid')
def valid_records():
    all_column_names = data_operations.get_all_column_names('data/valid_records.xlsx')
    total_columns = len(all_column_names)
    total_column_pages = math.ceil(total_columns / COLS_PER_PAGE)

    # Get the current column page from the request URL (default to 1)
    try:
        current_col_page = int(request.args.get('col_page', 1))
    except ValueError:
        current_col_page = 1 # Default to 1 if the parameter is invalid

    # Ensure current_col_page is within valid range
    if current_col_page < 1:
        current_col_page = 1
    elif current_col_page > total_column_pages and total_column_pages > 0:
        current_col_page = total_column_pages
    elif total_column_pages == 0: # Handle case with no columns
         current_col_page = 1


    # Calculate the start and end index for column slicing
    start_col_index = (current_col_page - 1) * COLS_PER_PAGE
    end_col_index = start_col_index + COLS_PER_PAGE

    # Get the subset of column names for the current page
    columns_to_show = all_column_names[start_col_index:end_col_index]

    # Fetch the records with only the selected columns
    valid_data = data_operations.get_valid_records(columns_to_fetch=columns_to_show)

    return render_template('valid_records.html',
                           valid_records=valid_data,
                           column_names=columns_to_show, # Pass column names for headers
                           current_col_page=current_col_page,
                           total_column_pages=total_column_pages)


@app.route('/download/<filename>')
def download_file(filename):
    file_path = f'data/{filename}'
    try:
        return send_file(file_path, as_attachment=True)
    except FileNotFoundError:
        return "File not found.", 404

@app.route('/download_sample/<filename>')
def download_sample_file(filename):
    file_path = f'data/{filename}'
    try:
        return send_file(file_path, as_attachment=True)
    except FileNotFoundError:
        return "Sample file not found.", 404


if __name__ == '__main__':
    # Ensure the data directory exists
    import os
    if not os.path.exists('data'):
        os.makedirs('data')
        # Run the data_operations test block to create dummy files
        print("Creating dummy data files...")
        import data_operations # This will run the if __name__ == '__main__': block
        print("Dummy files created.")

    app.run(debug=True)