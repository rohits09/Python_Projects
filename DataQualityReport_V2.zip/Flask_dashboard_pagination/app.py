from flask import Flask, render_template, send_file, request, abort
import data_operations
import math
import os
import pandas as pd # Import pandas for date handling
from datetime import datetime # Import datetime

app = Flask(__name__)

# Define how many columns to show per page on detail pages
COLS_PER_PAGE = 7

# Define how many historical runs to show per page on the home page
ITEMS_PER_PAGE_HOME = 10 # You can adjust this number

# Path to the historical runs metadata file
METADATA_FILE = 'data/historical_runs.txt'

# Helper function to get run metadata
def get_run_metadata(run_id):
    """Finds metadata for a specific run_id."""
    historical_runs = data_operations.get_historical_runs(METADATA_FILE)
    return next((run for run in historical_runs if run['run_id'] == run_id), None)

@app.route('/')
def index():
    """Home page showing the list of historical runs with filtering and pagination."""
    # Get filter and pagination parameters from the request URL
    start_date_str = request.args.get('start_date')
    end_date_str = request.args.get('end_date')
    page = request.args.get('page', 1, type=int) # Default to page 1

    # Read all historical runs metadata
    historical_runs_df = pd.read_csv(METADATA_FILE)

    # Add 'sr_no' column for display (before filtering/pagination)
    historical_runs_df.insert(0, 'sr_no', range(1, 1 + len(historical_runs_df)))

    # Convert 'file_run_date' to datetime objects for filtering
    try:
        # Use errors='coerce' to turn unparseable dates into NaT (Not a Time)
        historical_runs_df['file_run_date'] = pd.to_datetime(historical_runs_df['file_run_date'], errors='coerce')
    except KeyError:
        # Handle case where 'file_run_date' column is missing
        print("Warning: 'file_run_date' column not found in metadata. Date filtering disabled.")
        start_date_str = None # Disable filtering if date column is missing
        end_date_str = None


    # Apply date range filtering
    filtered_runs_df = historical_runs_df.copy() # Work on a copy

    start_date = None
    if start_date_str:
        try:
            start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
            # Filter rows where run date is on or after start_date
            filtered_runs_df = filtered_runs_df[filtered_runs_df['file_run_date'] >= start_date]
        except ValueError:
            # Handle invalid start date format
            print(f"Warning: Invalid start date format: {start_date_str}")
            start_date_str = None # Clear invalid date


    end_date = None
    if end_date_str:
        try:
            end_date = datetime.strptime(end_date_str, '%Y-%m-%d')
             # Filter rows where run date is on or before end_date
            filtered_runs_df = filtered_runs_df[filtered_runs_df['file_run_date'] <= end_date]
        except ValueError:
            # Handle invalid end date format
            print(f"Warning: Invalid end date format: {end_date_str}")
            end_date_str = None # Clear invalid date


    # --- Pagination Logic ---
    total_items = len(filtered_runs_df)
    total_pages = math.ceil(total_items / ITEMS_PER_PAGE_HOME) if ITEMS_PER_PAGE_HOME > 0 else 1

    # Ensure current page is within valid range
    if page < 1:
        page = 1
    elif page > total_pages and total_pages > 0:
        page = total_pages
    elif total_pages == 0:
        page = 1 # If no items, stay on page 1

    # Calculate the start and end index for slicing
    start_index = (page - 1) * ITEMS_PER_PAGE_HOME
    end_index = start_index + ITEMS_PER_PAGE_HOME

    # Get the paginated subset of runs
    paginated_runs_df = filtered_runs_df.iloc[start_index:end_index]

    # Convert the paginated DataFrame back to a list of dictionaries for the template
    paginated_runs = paginated_runs_df.to_dict('records')

    # --- Render the template ---
    return render_template('index.html',
                           historical_runs=paginated_runs,
                           current_page=page,
                           total_pages=total_pages,
                           start_date=start_date_str, # Pass the input dates back
                           end_date=end_date_str,
                           total_items=total_items, # Pass total items for display
                           items_per_page=ITEMS_PER_PAGE_HOME # Pass items per page
                           )

# Keep the rest of the routes as they are (run_summary, run_invalid_records, run_valid_records, download_file)
@app.route('/run_summary/<run_id>')
def run_summary(run_id):
    """Summary page for a specific historical run."""
    run_metadata = get_run_metadata(run_id)

    if run_metadata is None:
        abort(404)

    summary_file_path = run_metadata.get('summary_file')
    if not summary_file_path or not os.path.exists(summary_file_path):
         summary_data = {'Valid Records': 0, 'Invalid Records': 0, 'Total Records': 0, 'message': f"Summary file not found: {summary_file_path}"}
    else:
        summary_data = data_operations.get_summary_data(summary_file_path)


    return render_template('run_summary.html',
                           run_metadata=run_metadata,
                           summary=summary_data)

@app.route('/run_invalid_records/<run_id>')
def run_invalid_records(run_id):
    """Invalid records detail page for a specific historical run."""
    run_metadata = get_run_metadata(run_id)

    if run_metadata is None:
        abort(404)

    invalid_file_path = run_metadata.get('invalid_file')

    if not invalid_file_path or not os.path.exists(invalid_file_path):
         return render_template('run_invalid_records.html',
                               run_metadata=run_metadata,
                               invalid_records=[],
                               invalid_column_names=[],
                               current_col_page=1,
                               total_col_pages=1,
                               message=f"Invalid records file not found: {invalid_file_path}")

    # --- Fetch Invalid Records (with column pagination logic) ---
    invalid_column_names = data_operations.get_all_column_names(invalid_file_path)
    total_invalid_cols = len(invalid_column_names)
    total_invalid_col_pages = math.ceil(total_invalid_cols / COLS_PER_PAGE) if COLS_PER_PAGE > 0 else 1

    try:
        current_invalid_col_page = int(request.args.get('invalid_col_page', 1))
    except ValueError:
        current_invalid_col_page = 1

    if current_invalid_col_page < 1:
        current_invalid_col_page = 1
    elif current_invalid_col_page > total_invalid_col_pages and total_invalid_col_pages > 0:
        current_invalid_col_page = total_invalid_col_pages
    elif total_invalid_col_pages == 0:
         current_invalid_col_page = 1


    start_col_index_invalid = (current_invalid_col_page - 1) * COLS_PER_PAGE
    end_col_index_invalid = start_col_index_invalid + COLS_PER_PAGE
    columns_to_show_invalid = invalid_column_names[start_col_index_invalid:end_col_index_invalid]

    invalid_records_data = data_operations.get_records(invalid_file_path, columns_to_fetch=columns_to_show_invalid)


    return render_template('run_invalid_records.html',
                           run_metadata=run_metadata,
                           invalid_records=invalid_records_data,
                           invalid_column_names=columns_to_show_invalid,
                           current_col_page=current_invalid_col_page,
                           total_col_pages=total_invalid_col_pages)


@app.route('/run_valid_records/<run_id>')
def run_valid_records(run_id):
    """Valid records detail page for a specific historical run."""
    run_metadata = get_run_metadata(run_id)

    if run_metadata is None:
        abort(404)

    valid_file_path = run_metadata.get('valid_file')

    if not valid_file_path or not os.path.exists(valid_file_path):
        return render_template('run_valid_records.html',
                               run_metadata=run_metadata,
                               valid_records=[],
                               valid_column_names=[],
                               current_col_page=1,
                               total_col_pages=1,
                               message=f"Valid records file not found: {valid_file_path}")


    # --- Fetch Valid Records (with column pagination logic) ---
    valid_column_names = data_operations.get_all_column_names(valid_file_path)
    total_valid_cols = len(valid_column_names)
    total_valid_col_pages = math.ceil(total_valid_cols / COLS_PER_PAGE) if COLS_PER_PAGE > 0 else 1

    try:
        current_valid_col_page = int(request.args.get('valid_col_page', 1)) # Use valid_col_page parameter
    except ValueError:
        current_valid_col_page = 1

    if current_valid_col_page < 1:
        current_valid_col_page = 1
    elif current_valid_col_page > total_valid_col_pages and total_valid_col_pages > 0:
        current_valid_col_page = total_valid_col_pages
    elif total_valid_col_pages == 0:
         current_valid_col_page = 1


    start_col_index_valid = (current_valid_col_page - 1) * COLS_PER_PAGE
    end_col_index_valid = start_col_index_valid + COLS_PER_PAGE
    columns_to_show_valid = valid_column_names[start_col_index_valid:end_col_index_valid]

    valid_records_data = data_operations.get_records(valid_file_path, columns_to_fetch=columns_to_show_valid)

    return render_template('run_valid_records.html',
                           run_metadata=run_metadata,
                           valid_records=valid_records_data,
                           valid_column_names=columns_to_show_valid,
                           current_col_page=current_valid_col_page,
                           total_col_pages=total_valid_col_pages)


# Modified download route to accept run_id and file_type
@app.route('/download/<run_id>/<file_type>')
def download_file(run_id, file_type):
    """Downloads a specific file type for a given historical run."""
    run_metadata = get_run_metadata(run_id)

    if run_metadata is None:
        abort(404)

    # Determine the correct file path based on file_type
    file_path = None
    if file_type == 'invalid':
        file_path = run_metadata.get('invalid_file')
    elif file_type == 'valid':
        file_path = run_metadata.get('valid_file')
    elif file_type == 'summary':
         file_path = run_metadata.get('summary_file') # Added summary download option

    if file_path and os.path.exists(file_path):
        # Infer filename for download (e.g., invalid_records_run_20230101.xlsx)
        base_filename = os.path.basename(file_path)
        # Sanitize file_type for use in download name
        safe_file_type = file_type.replace(' ', '_')
        download_name = f"{safe_file_type}_records_{run_id}{os.path.splitext(base_filename)[1]}" if file_type in ['invalid', 'valid'] else f"{run_id}_{base_filename}"
        return send_file(file_path, as_attachment=True, download_name=download_name)
    else:
        return "File not found for this run and type.", 404


if __name__ == '__main__':
    # Ensure the data directory exists
    import os
    if not os.path.exists('data'):
        os.makedirs('data')

    print("Please ensure 'data/historical_runs.txt' and historical data subdirectories exist.")
    app.run(debug=True)