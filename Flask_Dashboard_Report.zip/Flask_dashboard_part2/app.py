from flask import Flask, render_template, send_file
import data_operations

app = Flask(__name__)

@app.route('/')
def index():
    summary_data = data_operations.get_summary_data()
    return render_template('index.html', summary=summary_data)

@app.route('/invalid')
def invalid_records():
    invalid_data = data_operations.get_invalid_records()
    return render_template('invalid_records.html', invalid_records=invalid_data)

@app.route('/valid')
def valid_records():
    valid_data = data_operations.get_valid_records()
    return render_template('valid_records.html', valid_records=valid_data)

@app.route('/download/<filename>')
def download_file(filename):
    file_path = f'data/{filename}'
    return send_file(file_path, as_attachment=True)

@app.route('/download_sample/<filename>')
def download_sample_file(filename):
    file_path = f'data/{filename}'
    return send_file(file_path, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)