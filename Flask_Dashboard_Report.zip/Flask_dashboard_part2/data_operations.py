import pandas as pd

def get_summary_data(file_path='data/summary.xlsx'):
    """Reads summary data from the Excel file."""
    try:
        df = pd.read_excel(file_path)
        summary = df.set_index('Metric')['Count'].to_dict()
        total_records = summary.get('Valid Records', 0) + summary.get('Invalid Records', 0)
        summary['Total Records'] = total_records
        return summary
    except FileNotFoundError:
        return {'Valid Records': 0, 'Invalid Records': 0, 'Total Records': 0}

def get_invalid_records(file_path='data/invalid_records.xlsx'):
    """Reads invalid records from the Excel file."""
    try:
        df = pd.read_excel(file_path)
        return df.to_dict('records')
    except FileNotFoundError:
        return []

def get_valid_records(file_path='data/valid_records.xlsx'):
    """Reads valid records from the Excel file."""
    try:
        df = pd.read_excel(file_path)
        return df.to_dict('records')
    except FileNotFoundError:
        return []