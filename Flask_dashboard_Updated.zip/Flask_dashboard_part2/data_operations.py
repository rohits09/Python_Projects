import pandas as pd

def get_summary_data(file_path='data/summary.xlsx'):
    """Reads summary data from the Excel file."""
    try:
        df = pd.read_excel(file_path)
        summary = df.set_index('Metric')['Count'].to_dict()
        # Calculate Total Records if not explicitly in the summary file
        total_records = summary.get('Valid Records', 0) + summary.get('Invalid Records', 0)
        summary['Total Records'] = total_records
        return summary
    except FileNotFoundError:
        return {'Valid Records': 0, 'Invalid Records': 0, 'Total Records': 0}
    except Exception as e:
        print(f"Error reading summary data: {e}")
        return {'Valid Records': 0, 'Invalid Records': 0, 'Total Records': 0}


def get_invalid_records(file_path='data/invalid_records.xlsx', columns=None):
    """
    Reads invalid records from the Excel file and selects specified columns.

    Args:
        file_path (str): The path to the invalid records Excel file.
        columns (list, optional): A list of column names to select.
                                  If None, all columns are returned.

    Returns:
        list: A list of dictionaries, where each dictionary represents a row
              with only the selected columns. Returns an empty list if the
              file is not found or an error occurs.
    """
    try:
        df = pd.read_excel(file_path)
        if columns and isinstance(columns, list):
            # Select only the specified columns
            # Handle cases where a specified column might not exist
            existing_columns = [col for col in columns if col in df.columns]
            df = df[existing_columns]
        return df.to_dict('records')
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return []
    except Exception as e:
        print(f"Error reading invalid records: {e}")
        return []


def get_valid_records(file_path='data/valid_records.xlsx', columns=None):
    """
    Reads valid records from the Excel file and selects specified columns.

    Args:
        file_path (str): The path to the valid records Excel file.
        columns (list, optional): A list of column names to select.
                                  If None, all columns are returned.

    Returns:
        list: A list of dictionaries, where each dictionary represents a row
              with only the selected columns. Returns an empty list if the
              file is not found or an error occurs.
    """
    try:
        df = pd.read_excel(file_path)
        if columns and isinstance(columns, list):
            # Select only the specified columns
             # Handle cases where a specified column might not exist
            existing_columns = [col for col in columns if col in df.columns]
            df = df[existing_columns]
        return df.to_dict('records')
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return []
    except Exception as e:
        print(f"Error reading valid records: {e}")
        return []
