import pandas as pd
import math
import os # Import os to check file extension

def get_historical_runs(metadata_file='data/historical_runs.csv'):
    """Reads the historical runs metadata from a CSV file."""
    try:
        df = pd.read_csv(metadata_file)
        # Add a 'sr_no' column for display purposes
        df.insert(0, 'sr_no', range(1, 1 + len(df)))
        return df.to_dict('records')
    except FileNotFoundError:
        print(f"Error: Metadata file not found at {metadata_file}")
        return []
    except Exception as e:
        print(f"Error reading historical runs metadata: {e}")
        return []

def read_data_file(file_path):
    """Reads data from Excel, CSV, or text files based on extension."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")

    file_extension = os.path.splitext(file_path)[1].lower()

    try:
        if file_extension == '.xlsx':
            df = pd.read_excel(file_path)
        elif file_extension in ['.csv', '.txt']:
            # For .csv and .txt, use read_csv. Pandas can often infer delimiters.
            # If your .txt files have a specific delimiter (e.g., tab), you might
            # need to add a 'delimiter='\t'' argument here or make it configurable.
            df = pd.read_csv(file_path)
        else:
            # Handle unsupported file types
            raise ValueError(f"Unsupported file format: {file_extension} for {file_path}")
        return df
    except Exception as e:
        print(f"Error reading data from {file_path}: {e}")
        raise # Re-raise the exception after printing

def get_summary_data(file_path):
    """Reads summary data from the specified Excel, CSV, or text file."""
    try:
        df = read_data_file(file_path)
        # Assuming the summary file always has 'Metric' and 'Count' columns
        if 'Metric' in df.columns and 'Count' in df.columns:
            summary = df.set_index('Metric')['Count'].to_dict()
            total_records = summary.get('Valid Records', 0) + summary.get('Invalid Records', 0)
            summary['Total Records'] = total_records
            return summary
        else:
            print(f"Warning: Summary file {file_path} does not contain 'Metric' and 'Count' columns.")
            return {'Valid Records': 0, 'Invalid Records': 0, 'Total Records': 0}
    except FileNotFoundError:
        print(f"Warning: Summary file not found at {file_path}. Returning zeros.")
        return {'Valid Records': 0, 'Invalid Records': 0, 'Total Records': 0}
    except Exception as e:
        print(f"Error processing summary data from {file_path}: {e}")
        return {'Valid Records': 0, 'Invalid Records': 0, 'Total Records': 0}


def get_all_column_names(file_path):
    """Reads the header row of a data file to get all column names."""
    try:
        # Read only a few rows to infer columns without loading the whole file
        df = read_data_file(file_path).head(0) # Read only the header
        return df.columns.tolist()
    except FileNotFoundError:
        print(f"Warning: File not found at {file_path}. Cannot get column names.")
        return []
    except Exception as e:
        print(f"Error getting column names from {file_path}: {e}")
        return []


def get_records(file_path, columns_to_fetch=None):
    """
    Reads records from the specified data file and selects specified columns.

    Args:
        file_path (str): The path to the records data file (.xlsx, .csv, .txt).
        columns_to_fetch (list, optional): A list of column names to select.
                                          If None, all columns are returned.

    Returns:
        list: A list of dictionaries, where each dictionary represents a row
              with only the specified columns. Returns an empty list if the
              file is not found or an error occurs.
    """
    try:
        df = read_data_file(file_path)
        if columns_to_fetch and isinstance(columns_to_fetch, list):
            # Select only the specified columns that actually exist
            existing_columns = [col for col in columns_to_fetch if col in df.columns]
            df = df[existing_columns]
         # Ensure data is returned as list of dictionaries, even if no columns were selected
        return df.to_dict('records') if not df.empty else []
    except FileNotFoundError:
        print(f"Warning: Records file not found at {file_path}. Returning empty list.")
        return []
    except Exception as e:
        print(f"Error reading records from {file_path}: {e}")
        return []
