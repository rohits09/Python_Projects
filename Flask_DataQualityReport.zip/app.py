from flask import Flask, render_template, send_file, request, abort
import data_operations
import math
import os

app = Flask(__name__)

# Define how many columns to show per page
COLS_PER_PAGE = 7 # You can adjust this number

# Path to the historical runs metadata file
METADATA_FILE = 'data/historical_runs.txt'

# Helper function to get run metadata
def get_run_metadata(run_id):
    """Finds metadata for a specific run_id."""
    historical_runs = data_operations.get_historical_runs(METADATA_FILE)
    return next((run for run in historical_runs if run['run_id'] == run_id), None)

@app.route('/')
def index():
    """Home page showing the list of historical runs."""
    historical_runs = data_operations.get_historical_runs(METADATA_FILE)
    return render_template('index.html', historical_runs=historical_runs)

@app.route('/run_summary/<run_id>')
def run_summary(run_id):
    """Summary page for a specific historical run."""
    run_metadata = get_run_metadata(run_id)

    if run_metadata is None:
        abort(404)

    summary_file_path = run_metadata.get('summary_file')
    if not summary_file_path or not os.path.exists(summary_file_path):
         summary_data = {'Valid Records': 0, 'Invalid Records': 0, 'Total Records': 0, 'message': f"Summary file not found: {summary_file_path}"}
    else:
        summary_data = data_operations.get_summary_data(summary_file_path)


    return render_template('run_summary.html',
                           run_metadata=run_metadata,
                           summary=summary_data)

@app.route('/run_invalid_records/<run_id>')
def run_invalid_records(run_id):
    """Invalid records detail page for a specific historical run."""
    run_metadata = get_run_metadata(run_id)

    if run_metadata is None:
        abort(404)

    invalid_file_path = run_metadata.get('invalid_file')

    if not invalid_file_path or not os.path.exists(invalid_file_path):
         return render_template('run_invalid_records.html',
                               run_metadata=run_metadata,
                               invalid_records=[],
                               invalid_column_names=[],
                               current_col_page=1,
                               total_col_pages=1,
                               message=f"Invalid records file not found: {invalid_file_path}")

    # --- Fetch Invalid Records (with column pagination logic) ---
    invalid_column_names = data_operations.get_all_column_names(invalid_file_path)
    total_invalid_cols = len(invalid_column_names)
    total_invalid_col_pages = math.ceil(total_invalid_cols / COLS_PER_PAGE) if COLS_PER_PAGE > 0 else 1 # Avoid division by zero

    try:
        current_invalid_col_page = int(request.args.get('invalid_col_page', 1))
    except ValueError:
        current_invalid_col_page = 1

    if current_invalid_col_page < 1:
        current_invalid_col_page = 1
    elif current_invalid_col_page > total_invalid_col_pages and total_invalid_col_pages > 0:
        current_invalid_col_page = total_invalid_col_pages
    elif total_invalid_col_pages == 0:
         current_invalid_col_page = 1


    start_col_index_invalid = (current_invalid_col_page - 1) * COLS_PER_PAGE
    end_col_index_invalid = start_col_index_invalid + COLS_PER_PAGE
    columns_to_show_invalid = invalid_column_names[start_col_index_invalid:end_col_index_invalid]

    invalid_records_data = data_operations.get_records(invalid_file_path, columns_to_fetch=columns_to_show_invalid)


    return render_template('run_invalid_records.html',
                           run_metadata=run_metadata,
                           invalid_records=invalid_records_data,
                           invalid_column_names=columns_to_show_invalid,
                           current_col_page=current_invalid_col_page,
                           total_col_pages=total_invalid_col_pages)


@app.route('/run_valid_records/<run_id>')
def run_valid_records(run_id):
    """Valid records detail page for a specific historical run."""
    run_metadata = get_run_metadata(run_id)

    if run_metadata is None:
        abort(404)

    valid_file_path = run_metadata.get('valid_file')

    if not valid_file_path or not os.path.exists(valid_file_path):
        return render_template('run_valid_records.html',
                               run_metadata=run_metadata,
                               valid_records=[],
                               valid_column_names=[],
                               current_col_page=1,
                               total_col_pages=1,
                               message=f"Valid records file not found: {valid_file_path}")


    # --- Fetch Valid Records (with column pagination logic) ---
    valid_column_names = data_operations.get_all_column_names(valid_file_path)
    total_valid_cols = len(valid_column_names)
    total_valid_col_pages = math.ceil(total_valid_cols / COLS_PER_PAGE) if COLS_PER_PAGE > 0 else 1 # Avoid division by zero

    try:
        current_valid_col_page = int(request.args.get('valid_col_page', 1)) # Use valid_col_page parameter
    except ValueError:
        current_valid_col_page = 1

    if current_valid_col_page < 1:
        current_valid_col_page = 1
    elif current_valid_col_page > total_valid_col_pages and total_valid_col_pages > 0:
        current_valid_col_page = total_valid_col_pages
    elif total_valid_col_pages == 0:
         current_valid_col_page = 1


    start_col_index_valid = (current_valid_col_page - 1) * COLS_PER_PAGE
    end_col_index_valid = start_col_index_valid + COLS_PER_PAGE
    columns_to_show_valid = valid_column_names[start_col_index_valid:end_col_index_valid]

    valid_records_data = data_operations.get_records(valid_file_path, columns_to_fetch=columns_to_show_valid)

    return render_template('run_valid_records.html',
                           run_metadata=run_metadata,
                           valid_records=valid_records_data,
                           valid_column_names=columns_to_show_valid,
                           current_col_page=current_valid_col_page,
                           total_col_pages=total_valid_col_pages)


# Modified download route to accept run_id and file_type
@app.route('/download/<run_id>/<file_type>')
def download_file(run_id, file_type):
    """Downloads a specific file type for a given historical run."""
    run_metadata = get_run_metadata(run_id)

    if run_metadata is None:
        abort(404)

    # Determine the correct file path based on file_type
    file_path = None
    if file_type == 'invalid':
        file_path = run_metadata.get('invalid_file')
    elif file_type == 'valid':
        file_path = run_metadata.get('valid_file')
    elif file_type == 'summary':
         file_path = run_metadata.get('summary_file') # Added summary download option

    if file_path and os.path.exists(file_path):
        # Infer filename for download (e.g., invalid_records_run_20230101.xlsx)
        base_filename = os.path.basename(file_path)
        # Sanitize file_type for use in download name
        safe_file_type = file_type.replace(' ', '_')
        download_name = f"{safe_file_type}_records_{run_id}{os.path.splitext(base_filename)[1]}" if file_type in ['invalid', 'valid'] else f"{run_id}_{base_filename}"
        return send_file(file_path, as_attachment=True, download_name=download_name)
    else:
        return "File not found for this run and type.", 404
    

if __name__ == '__main__':
    # Ensure the data directory exists
    import os
    if not os.path.exists('data'):
        os.makedirs('data')

    print("Please ensure 'data/historical_runs.txt' and historical data subdirectories exist.")
    app.run(debug=True)